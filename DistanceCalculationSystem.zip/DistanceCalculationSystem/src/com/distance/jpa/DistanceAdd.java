package com.distance.jpa;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DistanceAdd {
	
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		
		EntityManagerFactory factory = 
				Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		Distance d = new Distance();
		double dmiles=0;
		double dm =0;
		System.out.println("Enter id for distance: ");
		d.setDistance_id(sc.nextInt());
		System.out.println("Source : ");
		d.setSource(sc.next());
		System.out.println("Destination : ");
		d.setDestination(sc.next());
		System.out.println("Distance(km): ");
		d.setDist_in_km(sc.nextInt());
		System.out.println("Distance(m)");
		dm = sc.nextInt();
		
		dmiles=1.61*(d.getDist_in_km());
		d.setDist_in_miles(dmiles);
		
		em.getTransaction().begin();
		
		em.persist(d);
	
		em.getTransaction().commit();
		System.out.println("DAta Added ");
		
		
	}
}







